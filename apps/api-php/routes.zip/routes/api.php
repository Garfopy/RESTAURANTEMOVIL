<?php

declare(strict_types=1);

// ── Autoload manual si vendor/autoload.php no existe ──
if (!class_exists(\Amare\Api\Controllers\AuthController::class)) {
    spl_autoload_register(function (string $class) {
        if (str_starts_with($class, 'Amare\\Api\\')) {
            $relative = str_replace('Amare\\Api\\', '', $class);
            $file = __DIR__ . '/../src/' . str_replace('\\', '/', $relative) . '.php';
            if (is_file($file)) {
                require_once $file;
            }
        }
    });
}

// ── Load lib helpers (needed by old-style PHP route files) ──
$libDir = dirname(__DIR__);
if (is_file($libDir . '/lib/db.php')) require_once $libDir . '/lib/db.php';
if (is_file($libDir . '/lib/auth.php')) require_once $libDir . '/lib/auth.php';
if (is_file($libDir . '/lib/util.php')) require_once $libDir . '/lib/util.php';

$requestMethod = $_SERVER['REQUEST_METHOD'];
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$basePath = dirname($_SERVER['SCRIPT_NAME']);

$routes = [
    // Auth routes
    ['POST', '/auth/register', ['Amare\Api\Controllers\AuthController', 'register']],
    ['POST', '/auth/login', ['Amare\Api\Controllers\AuthController', 'login']],
    ['POST', '/auth/google', ['Amare\Api\Controllers\AuthController', 'google']],
    ['GET', '/auth/me', ['Amare\Api\Controllers\AuthController', 'me']],
    ['PUT', '/auth/update-password', ['Amare\Api\Controllers\AuthController', 'updatePassword']],
    
    // Branches routes
    ['GET', '/branches', ['Amare\Api\Controllers\BranchController', 'index']],
    ['GET', '/branches/:id', ['Amare\Api\Controllers\BranchController', 'show']],
    
    // Menu routes
    ['GET', '/menu/categories', ['Amare\Api\Controllers\MenuController', 'categories']],
    ['GET', '/menu/products', ['Amare\Api\Controllers\MenuController', 'products']],
    ['GET', '/menu/products/:id', ['Amare\Api\Controllers\MenuController', 'showProduct']],
    
    // Orders routes
    ['GET', '/orders', ['Amare\Api\Controllers\OrderController', 'index']],
    ['GET', '/orders/:id', ['Amare\Api\Controllers\OrderController', 'show']],
    ['POST', '/orders', ['Amare\Api\Controllers\OrderController', 'store']],
    
    // Payments routes
    ['POST', '/payments/create-intent', ['Amare\Api\Controllers\PaymentController', 'createPaymentIntent']],
    ['POST', '/payments/webhook', ['Amare\Api\Controllers\PaymentController', 'webhook']],
    
    // Profile routes
    ['GET', '/profile', ['Amare\Api\Controllers\ProfileController', 'show']],
    ['PUT', '/profile', ['Amare\Api\Controllers\ProfileController', 'update']],
    ['GET', '/profile/orders', ['Amare\Api\Controllers\ProfileController', 'orders']],
    ['POST', '/profile/avatar', ['Amare\Api\Controllers\ProfileController', 'updateAvatar']],
    
    // Address routes
    ['GET', '/profile/addresses', ['Amare\Api\Controllers\AddressController', 'index']],
    ['POST', '/profile/addresses', ['Amare\Api\Controllers\AddressController', 'store']],
    ['GET', '/profile/addresses/:id', ['Amare\Api\Controllers\AddressController', 'show']],
    ['PUT', '/profile/addresses/:id', ['Amare\Api\Controllers\AddressController', 'update']],
    ['DELETE', '/profile/addresses/:id', ['Amare\Api\Controllers\AddressController', 'destroy']],
    
    // Favorites routes
    ['GET', '/favorites', ['Amare\Api\Controllers\FavoritesController', 'index']],
    ['POST', '/favorites/toggle', ['Amare\Api\Controllers\FavoritesController', 'toggle']],
    
    // Promotions routes
    ['GET', '/promotions', ['Amare\Api\Controllers\PromotionsController', 'index']],
    ['GET', '/promotions/:id', ['Amare\Api\Controllers\PromotionsController', 'show']],
    ['POST', '/promotions/validate', ['Amare\Api\Controllers\PromotionsController', 'validateCode']],

    // Social routes (direct require to avoid autoloader issues)
    ['POST', '/users/social-status', 'social/update_status.php'],
    ['PATCH', '/users/social-status', 'social/update_status.php'],
    ['GET', '/users/social-profile', 'social/get_profile.php'],
    ['PUT', '/users/social-profile', 'social/update_profile.php'],
    ['POST', '/users/social-photo', 'social/upload_photo.php'],
    ['GET', '/users/:id/public-profile', 'social/public_profile.php'],
    ['GET', '/restaurants/:id/active-diners', 'social/active_diners.php'],
    ['GET', '/gift-products', '../routes/gifts/list.php'],
];

// Remove base path from request URI
$requestPath = str_replace($basePath, '', $requestUri);

if (empty($requestPath)) {
    $requestPath = '/';
}

// Find matching route
$matchedRoute = null;
$routeParams = [];

foreach ($routes as $route) {
    [$routeMethod, $routePath, $handler] = $route;
    
    if ($routeMethod !== $requestMethod) {
        continue;
    }
    
    // Convert route pattern to regex
    $pattern = preg_replace('/:\w+/', '(\d+)', $routePath);
    $pattern = '#^' . $pattern . '$#';
    
    if (preg_match($pattern, $requestPath, $matches)) {
        $matchedRoute = $route;
        
        // Extract route parameters
        preg_match_all('/:(\w+)/', $routePath, $paramNames);
        foreach ($paramNames[1] as $index => $paramName) {
            $routeParams[$paramName] = (int)$matches[$index + 1];
        }
        
        break;
    }
}

if (!$matchedRoute) {
    http_response_code(404);
    echo json_encode([
        'ok' => false,
        'message' => 'Endpoint no encontrado'
    ]);
    exit;
}

// Call handler — can be a controller array or a file path string
$handler = $matchedRoute[2];

if (is_string($handler)) {
    // Direct file require (like the old api.php)
    $handlerFile = __DIR__ . '/' . $handler;
    if (!is_file($handlerFile)) {
        $handlerFile = dirname(__DIR__) . '/routes/' . $handler;
    }
    if (is_file($handlerFile)) {
        require $handlerFile;
        exit;
    }
    json_response(['detail' => 'Handler file not found: ' . $handler], 500);
    exit;
}

if (is_array($handler)) {
    $controller = new $handler[0]();
    $method = $handler[1];
    
    if (!empty($routeParams)) {
        call_user_func_array([$controller, $method], $routeParams);
    } else {
        $controller->$method();
    }
}
